<?php
/**
 * Uninstall handler for Filterable Gallery for Divi 5.
 *
 * This file runs when the plugin is deleted via the WordPress admin
 * (Plugins → installed plugins → Delete).
 *
 * IMPORTANT: This file is INTENTIONALLY EMPTY of destructive operations.
 *
 * Plugin data — taxonomy terms, image taggings, custom CSS, settings —
 * is preserved by default when the plugin is uninstalled. This protects
 * users from accidentally losing their work.
 *
 * Users who want to fully reset all plugin data should use the explicit
 * "Reset All Plugin Data" button in the plugin settings page BEFORE
 * uninstalling. That action requires multi-step confirmation, making
 * destructive deletion deliberate rather than accidental.
 *
 * If you've used the Reset button in settings and the data is already
 * cleared, this file has nothing to clean up. If you haven't, your
 * categories and tagged images remain in the database — re-installing
 * the plugin will pick them up exactly where you left off.
 *
 * @package Divi5_Filterable_Gallery
 */

// Exit if accessed directly outside of the WordPress uninstall flow.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Intentionally empty.
// See plugin settings page for the explicit "Reset All Plugin Data" option.

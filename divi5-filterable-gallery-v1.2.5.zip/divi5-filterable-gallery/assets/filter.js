/**
 * Filterable Gallery for Divi 5 — Frontend Filter Logic
 *
 * Listens for clicks on filter buttons, toggles a CSS class on each
 * gallery item to show/hide based on the data-categories attribute,
 * manages active button state, and supports a URL ?filter= parameter
 * for shareable filtered views.
 *
 * Vanilla JS, no jQuery dependency.
 *
 * @package Divi5_Filterable_Gallery
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', init);

	/**
	 * Initialize all filter bars on the page.
	 */
	function init() {
		var filterBars = document.querySelectorAll('.dfg-gallery-filters');
		if (!filterBars.length) {
			return;
		}

		filterBars.forEach(setupFilterBar);

		// If URL has ?filter=slug parameter, apply on load.
		var initialFilter = getUrlParam('filter');
		if (initialFilter) {
			applyFilter(initialFilter);
			setActiveButton(initialFilter);
		}
	}

	/**
	 * Bind click handlers to all filter buttons in a bar.
	 */
	function setupFilterBar(bar) {
		var buttons = bar.querySelectorAll('a[data-filter]');
		buttons.forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				var filter = btn.getAttribute('data-filter');
				applyFilter(filter);
				setActiveButton(filter);
				updateUrl(filter);
			});
		});
	}

	/**
	 * Show/hide gallery items based on selected filter.
	 */
	function applyFilter(filter) {
		var items = document.querySelectorAll('.et_pb_gallery_item');
		var visibleCount = 0;

		items.forEach(function (item) {
			var categories = (item.getAttribute('data-categories') || '').split(' ');
			var shouldShow = filter === 'all' || categories.indexOf(filter) !== -1;

			if (shouldShow) {
				item.classList.remove('dfg-hidden');
				visibleCount++;
			} else {
				item.classList.add('dfg-hidden');
			}
		});

		// Optional external count display element.
		var countEl = document.querySelector('.dfg-gallery-count');
		if (countEl) {
			countEl.textContent =
				visibleCount + ' image' + (visibleCount === 1 ? '' : 's');
		}
	}

	/**
	 * Set active state on the matching filter button.
	 * Updates aria-pressed and aria-current for accessibility.
	 */
	function setActiveButton(filter) {
		// Clear all active states
		document.querySelectorAll('.dfg-gallery-filters .dfg-filter').forEach(
			function (li) {
				li.classList.remove('active');
			}
		);

		document.querySelectorAll('.dfg-gallery-filters a[data-filter]').forEach(
			function (btn) {
				btn.setAttribute('aria-pressed', 'false');
				btn.removeAttribute('aria-current');
			}
		);

		// Set active state on the matching button
		var activeBtns = document.querySelectorAll(
			'.dfg-gallery-filters a[data-filter="' + filter + '"]'
		);
		activeBtns.forEach(function (btn) {
			btn.parentElement.classList.add('active');
			btn.setAttribute('aria-pressed', 'true');
			btn.setAttribute('aria-current', 'true');
		});
	}

	/**
	 * Read a URL query parameter.
	 */
	function getUrlParam(name) {
		var params = new URLSearchParams(window.location.search);
		return params.get(name);
	}

	/**
	 * Update URL with current filter state for shareable URLs.
	 */
	function updateUrl(filter) {
		if (!window.history || !window.history.replaceState) {
			return;
		}

		var url = new URL(window.location.href);
		if (filter === 'all') {
			url.searchParams.delete('filter');
		} else {
			url.searchParams.set('filter', filter);
		}
		window.history.replaceState({}, '', url.toString());
	}
})();

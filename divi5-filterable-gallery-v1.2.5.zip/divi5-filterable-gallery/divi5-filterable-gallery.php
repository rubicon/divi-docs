<?php
/**
 * Plugin Name:       Filterable Gallery for Divi 5
 * Plugin URI:        https://16wells.github.io/divi-docs/recipes/divi5-filterable-gallery/
 * Description:       Adds Media Library category tagging and filter buttons to the Divi 5 Gallery module. Tag images once in the Media Library, filter them on the front end with native-styled buttons.
 * Version:           1.2.5
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            16wells
 * Author URI:        https://16wells.github.io/divi-docs/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       divi5-filterable-gallery
 * Domain Path:       /languages
 *
 * @package Divi5_Filterable_Gallery
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// =============================================================================
// Plugin Constants
// =============================================================================

define( 'DFG_VERSION', '1.2.5' );
define( 'DFG_PLUGIN_FILE', __FILE__ );
define( 'DFG_PATH', plugin_dir_path( __FILE__ ) );
define( 'DFG_URL', plugin_dir_url( __FILE__ ) );
define( 'DFG_TAXONOMY', 'gallery_category' );


// =============================================================================
// Activation / Deactivation
// =============================================================================

/**
 * Plugin activation hook.
 *
 * Registers the taxonomy so it's immediately available, then flushes
 * rewrite rules so the REST API endpoint becomes accessible. We do
 * NOT seed any default terms — this is a generic plugin and seeding
 * arbitrary categories on activation would be presumptuous.
 *
 * @return void
 */
function dfg_activate() {
	dfg_register_taxonomy();
	flush_rewrite_rules();

	// Seed the default custom CSS option on first activation only.
	// Uses add_option() rather than update_option() so we don't clobber
	// existing user CSS on plugin reactivation.
	if ( ! file_exists( DFG_PATH . 'admin/settings-page.php' ) ) {
		return;
	}
	require_once DFG_PATH . 'admin/settings-page.php';
	add_option( 'dfg_custom_css', dfg_default_custom_css() );
}
register_activation_hook( __FILE__, 'dfg_activate' );

/**
 * Plugin deactivation hook.
 *
 * Flushes rewrite rules. Plugin data is preserved.
 *
 * @return void
 */
function dfg_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'dfg_deactivate' );


// =============================================================================
// Layer 1: Custom Taxonomy on Attachments
// =============================================================================

/**
 * Register the gallery_category taxonomy and attach it to the attachment
 * post type. Exposed via REST API for future extensibility.
 *
 * @return void
 */
function dfg_register_taxonomy() {
	$labels = array(
		'name'                  => __( 'Gallery Categories', 'divi5-filterable-gallery' ),
		'singular_name'         => __( 'Gallery Category', 'divi5-filterable-gallery' ),
		'menu_name'             => __( 'Gallery Categories', 'divi5-filterable-gallery' ),
		'all_items'             => __( 'All Gallery Categories', 'divi5-filterable-gallery' ),
		'parent_item'           => __( 'Parent Gallery Category', 'divi5-filterable-gallery' ),
		'parent_item_colon'     => __( 'Parent Gallery Category:', 'divi5-filterable-gallery' ),
		'edit_item'             => __( 'Edit Gallery Category', 'divi5-filterable-gallery' ),
		'view_item'             => __( 'View Gallery Category', 'divi5-filterable-gallery' ),
		'update_item'           => __( 'Update Gallery Category', 'divi5-filterable-gallery' ),
		'add_new_item'          => __( 'Add New Gallery Category', 'divi5-filterable-gallery' ),
		'new_item_name'         => __( 'New Gallery Category Name', 'divi5-filterable-gallery' ),
		'search_items'          => __( 'Search Gallery Categories', 'divi5-filterable-gallery' ),
		'not_found'             => __( 'No gallery categories found.', 'divi5-filterable-gallery' ),
		'items_list_navigation' => __( 'Gallery categories list navigation', 'divi5-filterable-gallery' ),
		'items_list'            => __( 'Gallery categories list', 'divi5-filterable-gallery' ),
	);

	register_taxonomy(
		DFG_TAXONOMY,
		array( 'attachment' ),
		array(
			'labels'                => $labels,
			'public'                => true,
			'publicly_queryable'    => false,
			'hierarchical'          => true,         // category-style checkbox UI; required for attachment modal compatibility
			'show_ui'               => true,
			'show_in_menu'          => 'upload.php', // surfaces under Media menu
			'show_admin_column'     => true,         // column in Media Library list view
			'show_in_rest'          => true,
			'rest_base'             => 'gallery-categories',
			'query_var'             => false,
			'rewrite'               => false,
			// Attachments are post_status=inherit, not publish, so the default
			// _update_post_term_count callback never increments. Use the generic
			// counter which counts ALL related objects regardless of status.
			'update_count_callback' => '_update_generic_term_count',
		)
	);
}
add_action( 'init', 'dfg_register_taxonomy' );




// =============================================================================
// Layer 1b: Override Attachment Modal Rendering
// =============================================================================
//
// The attachment details modal (when clicking an image in Media Library grid
// view) uses its own rendering pipeline that ignores the taxonomy's
// `hierarchical` setting. By default it shows ALL custom taxonomies as
// comma-separated text inputs — even hierarchical ones. This is a longstanding
// WordPress core limitation.
//
// We override that rendering via attachment_fields_to_edit to inject a
// checkbox UI, then handle the save side via attachment_fields_to_save.
// =============================================================================

/**
 * Render the gallery_category taxonomy as a checkbox list inside the
 * attachment details modal, replacing WordPress core's default
 * comma-separated text input.
 *
 * @param array   $form_fields Existing form fields.
 * @param WP_Post $post        The attachment post object.
 * @return array Modified form fields.
 */
function dfg_render_modal_checkboxes( $form_fields, $post ) {
	if ( ! taxonomy_exists( DFG_TAXONOMY ) ) {
		return $form_fields;
	}

	$terms = get_terms(
		array(
			'taxonomy'   => DFG_TAXONOMY,
			'hide_empty' => false,
		)
	);

	if ( is_wp_error( $terms ) ) {
		return $form_fields;
	}

	$assigned = wp_get_object_terms(
		$post->ID,
		DFG_TAXONOMY,
		array( 'fields' => 'ids' )
	);

	if ( is_wp_error( $assigned ) ) {
		$assigned = array();
	}

	if ( empty( $terms ) ) {
		$add_url = admin_url( 'edit-tags.php?taxonomy=' . DFG_TAXONOMY . '&post_type=attachment' );
		$html    = '<p style="margin:0;color:#646970;">' . sprintf(
			/* translators: %s: URL to the gallery categories admin page */
			wp_kses(
				__( 'No gallery categories yet. <a href="%s">Add some</a> first.', 'divi5-filterable-gallery' ),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $add_url )
		) . '</p>';
	} else {
		$html  = '<ul class="dfg-modal-categories" style="margin:0;padding:0;list-style:none;max-height:200px;overflow-y:auto;border:1px solid #dcdcde;border-radius:3px;padding:8px 12px;background:#fff;">';
		foreach ( $terms as $term ) {
			$checked = in_array( $term->term_id, $assigned, true ) ? 'checked' : '';
			$html   .= sprintf(
				'<li style="margin:0 0 4px;"><label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;"><input type="checkbox" name="attachments[%d][%s][]" value="%d" %s> %s</label></li>',
				$post->ID,
				esc_attr( DFG_TAXONOMY ),
				$term->term_id,
				$checked,
				esc_html( $term->name )
			);
		}
		$html .= '</ul>';
	}

	// Hidden marker so we know the form was rendered, even if user unchecks all.
	$html .= sprintf(
		'<input type="hidden" name="attachments[%d][_dfg_marker]" value="1">',
		$post->ID
	);

	$form_fields[ DFG_TAXONOMY ] = array(
		'label' => __( 'Gallery Categories', 'divi5-filterable-gallery' ),
		'input' => 'html',
		'html'  => $html,
	);

	return $form_fields;
}
add_filter( 'attachment_fields_to_edit', 'dfg_render_modal_checkboxes', 10, 2 );

/**
 * Save gallery_category selections from the attachment details modal.
 *
 * The hidden _dfg_marker field tells us the form was rendered. This lets
 * us distinguish "no checkboxes submitted because user unchecked all"
 * from "form not submitted at all."
 *
 * @param array $post       Post data being saved.
 * @param array $attachment Attachment fields submitted.
 * @return array Unmodified post data (we save terms as a side effect).
 */
function dfg_save_modal_categories( $post, $attachment ) {
	// Only act if our marker is present, meaning the user actually saw our UI.
	if ( ! isset( $attachment['_dfg_marker'] ) ) {
		return $post;
	}

	$term_ids = isset( $attachment[ DFG_TAXONOMY ] )
		? array_map( 'intval', (array) $attachment[ DFG_TAXONOMY ] )
		: array();

	$term_ids = array_filter( $term_ids ); // strip zeros

	wp_set_object_terms( $post['ID'], $term_ids, DFG_TAXONOMY );

	return $post;
}
add_filter( 'attachment_fields_to_save', 'dfg_save_modal_categories', 10, 2 );


// =============================================================================
// Layer 2: Inject data-categories into Divi Gallery output
// =============================================================================

/**
 * Walk gallery output HTML and inject data-categories on each
 * .et_pb_gallery_item based on the attached image's gallery_category terms.
 *
 * Pure function — takes HTML in, returns HTML out. Called from both the
 * Divi 5 block render hook and the legacy shortcode output filter, so
 * we cover both rendering paths.
 *
 * @param string $html The gallery HTML to process.
 * @return string Modified HTML.
 */
function dfg_inject_categories_into_html( $html ) {
	if ( empty( $html ) || ! class_exists( 'DOMDocument' ) ) {
		return $html;
	}

	// Quick bailout: if there are no gallery items in the HTML at all,
	// don't bother spinning up DOMDocument.
	//
	// Divi 5 renders gallery wrappers as `.et_pb_gallery_image`. Older Divi 4
	// content may still use `.et_pb_gallery_item`. Bail only if NEITHER is present.
	if ( false === strpos( $html, 'et_pb_gallery_image' ) && false === strpos( $html, 'et_pb_gallery_item' ) ) {
		return $html;
	}

	// Suppress libxml warnings — Divi's HTML5 output isn't strict XHTML.
	$previous = libxml_use_internal_errors( true );
	$dom      = new DOMDocument();

	$dom->loadHTML(
		'<?xml encoding="UTF-8">' . $html,
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
	);

	libxml_clear_errors();
	libxml_use_internal_errors( $previous );

	$xpath = new DOMXPath( $dom );
	// Match either Divi 5 (`et_pb_gallery_image`) or Divi 4 (`et_pb_gallery_item`)
	// wrappers. The `concat(" ", normalize-space(@class), " ")` pattern is the
	// XPath idiom for whole-word class matching.
	$items = $xpath->query(
		'//*[contains(concat(" ", normalize-space(@class), " "), " et_pb_gallery_image ")'
		. ' or contains(concat(" ", normalize-space(@class), " "), " et_pb_gallery_item ")]'
	);

	if ( false === $items || 0 === $items->length ) {
		return $html;
	}

	foreach ( $items as $item ) {
		$imgs = $item->getElementsByTagName( 'img' );
		if ( 0 === $imgs->length ) {
			continue;
		}

		$img     = $imgs->item( 0 );
		$classes = $img->getAttribute( 'class' );

		// WordPress core stamps wp-image-{ID} on every attachment image.
		if ( ! preg_match( '/wp-image-(\d+)/', $classes, $matches ) ) {
			continue;
		}

		$attachment_id = (int) $matches[1];
		$terms         = get_the_terms( $attachment_id, DFG_TAXONOMY );

		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			$item->setAttribute( 'data-categories', '' );
			continue;
		}

		$slugs = wp_list_pluck( $terms, 'slug' );
		$item->setAttribute( 'data-categories', implode( ' ', $slugs ) );
	}

	// Serialize back to HTML and strip the XML declaration we prepended.
	$modified = $dom->saveHTML();
	$modified = preg_replace( '/^<\?xml[^>]*\?>\s*/', '', $modified );

	return $modified;
}

/**
 * Hook into Divi 5 block render — the primary code path for Divi 5 galleries.
 *
 * Divi 5 renders modules as blocks (block name `divi/gallery`), bypassing
 * the legacy shortcode pipeline entirely. WordPress core's `render_block`
 * filter fires for every block including Divi's, giving us a reliable hook
 * that doesn't depend on Divi-specific filter behavior.
 *
 * @param string $block_content The block's rendered HTML.
 * @param array  $block         The block array (includes blockName).
 * @return string Modified content.
 */
function dfg_filter_block_output( $block_content, $block ) {
	if ( ! isset( $block['blockName'] ) || 'divi/gallery' !== $block['blockName'] ) {
		return $block_content;
	}
	return dfg_inject_categories_into_html( $block_content );
}
add_filter( 'render_block', 'dfg_filter_block_output', 10, 2 );

/**
 * Fallback hook for any Divi 4-style shortcode rendering path.
 *
 * Divi 5 generally uses blocks, but this hook fires in some transitional
 * configurations or for content authored in Divi 4 and migrated forward.
 * Idempotent with the block hook — if both fire, the second call is a
 * no-op because data-categories is already set on the elements.
 *
 * @param string $output      The module's HTML output.
 * @param string $render_slug The module's render slug.
 * @param object $module      The module instance (unused).
 * @return string Modified output.
 */
function dfg_filter_module_output( $output, $render_slug, $module ) {
	if ( 'et_pb_gallery' !== $render_slug ) {
		return $output;
	}
	return dfg_inject_categories_into_html( $output );
}
add_filter( 'et_module_shortcode_output', 'dfg_filter_module_output', 10, 3 );


// =============================================================================
// Layer 3: Filter UI Shortcode [dfg_gallery_filters]
// =============================================================================

/**
 * Render the filter button row.
 *
 * Outputs a <ul> of filter buttons. Includes "All" reset button as the
 * first item, then one button per gallery_category term that has at
 * least one tagged image.
 *
 * Markup mirrors .et_pb_portfolio_filters > li > a.active to inherit
 * Divi's native filterable portfolio styling for visual consistency.
 *
 * @param array $atts Shortcode attributes.
 * @return string Rendered HTML.
 */
function dfg_filters_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'all_label'   => __( 'All', 'divi5-filterable-gallery' ),
			'show_counts' => 'no',
			'default'     => 'all',
			'taxonomy'    => DFG_TAXONOMY,
		),
		$atts,
		'dfg_gallery_filters'
	);

	$terms = get_terms(
		array(
			'taxonomy'   => $atts['taxonomy'],
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
		)
	);

	if ( empty( $terms ) || is_wp_error( $terms ) ) {
		return '';
	}

	ob_start();
	?>
	<div class="dfg-gallery-filters et_pb_portfolio_filters"
		data-default="<?php echo esc_attr( $atts['default'] ); ?>"
		role="group"
		aria-label="<?php esc_attr_e( 'Filter gallery by category', 'divi5-filterable-gallery' ); ?>">
		<ul class="clearfix">
			<?php $all_active = ( 'all' === $atts['default'] ); ?>
			<li class="dfg-filter <?php echo $all_active ? 'active' : ''; ?>">
				<a href="#"
					data-filter="all"
					aria-pressed="<?php echo $all_active ? 'true' : 'false'; ?>"
					<?php echo $all_active ? 'aria-current="true"' : ''; ?>>
					<?php echo esc_html( $atts['all_label'] ); ?>
				</a>
			</li>
			<?php foreach ( $terms as $term ) :
				$is_active = ( $term->slug === $atts['default'] );
				?>
				<li class="dfg-filter <?php echo $is_active ? 'active' : ''; ?>">
					<a href="#"
						data-filter="<?php echo esc_attr( $term->slug ); ?>"
						aria-pressed="<?php echo $is_active ? 'true' : 'false'; ?>"
						<?php echo $is_active ? 'aria-current="true"' : ''; ?>>
						<?php echo esc_html( $term->name ); ?>
						<?php if ( 'yes' === $atts['show_counts'] ) : ?>
							<span class="dfg-count">(<?php echo (int) $term->count; ?>)</span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'dfg_gallery_filters', 'dfg_filters_shortcode' );


// =============================================================================
// Layer 5: Frontend Asset Enqueue
// =============================================================================

/**
 * Register and enqueue frontend filter JavaScript and CSS.
 *
 * Loads on every front-end page. For sites with strict performance
 * requirements, gate this with is_singular() or a check for the
 * shortcode in $post->post_content.
 *
 * @return void
 */
function dfg_enqueue_frontend_assets() {
	wp_enqueue_script(
		'dfg-filter',
		DFG_URL . 'assets/filter.js',
		array(),
		DFG_VERSION,
		true
	);

	wp_enqueue_style(
		'dfg-filter',
		DFG_URL . 'assets/filter.css',
		array(),
		DFG_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'dfg_enqueue_frontend_assets' );


// =============================================================================
// Admin Settings (Chunk 2)
// =============================================================================

/**
 * Load the admin settings page module on admin requests only.
 *
 * Settings registration, render callback, and asset enqueue all live
 * in admin/settings-page.php to keep the main plugin file lean.
 */
if ( is_admin() ) {
	require_once DFG_PATH . 'admin/settings-page.php';

	add_action( 'admin_menu',            'dfg_register_settings_page' );
	add_action( 'admin_init',            'dfg_register_settings' );
	add_action( 'admin_enqueue_scripts', 'dfg_enqueue_admin_assets' );
}

/**
 * Print the user's custom CSS in <head> on the front end.
 *
 * Priority 100 ensures this runs AFTER the plugin's default styles
 * (which load via wp_enqueue_style at default priority), so user
 * rules naturally win the cascade without needing !important.
 *
 * Uses single-quoted strings for the static HTML so no quote escaping
 * is needed — defensive against future patch tooling.
 *
 * @return void
 */
function dfg_output_user_css() {
	$css = get_option( 'dfg_custom_css', '' );

	if ( empty( $css ) || ! is_string( $css ) ) {
		return;
	}

	// esc_html() neutralizes any stray angle brackets that survived
	// sanitization. CSS itself can't execute, so this is sufficient.
	echo '<style id="dfg-custom-css">' . "\n" . esc_html( $css ) . "\n" . '</style>' . "\n";
}
add_action( 'wp_head', 'dfg_output_user_css', 100 );


// =============================================================================
// Internationalization
// =============================================================================

/**
 * Load plugin text domain for translations.
 *
 * @return void
 */
function dfg_load_textdomain() {
	load_plugin_textdomain(
		'divi5-filterable-gallery',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
}
add_action( 'plugins_loaded', 'dfg_load_textdomain' );

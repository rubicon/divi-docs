=== Filterable Gallery for Divi 5 ===
Contributors: 16wells
Tags: divi, divi5, gallery, filter, media library, taxonomy
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.2.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds Media Library category tagging and filter buttons to the Divi 5 Gallery module. Tag images once, filter them on the front end.

== Description ==

Filterable Gallery for Divi 5 turns the standard Divi 5 Gallery module into a category-filterable experience without replacing the module or adding a third-party gallery system. Categorization happens directly in the WordPress Media Library, so a single image can appear in multiple filtered views just by tagging it.

**How it works:**

1. Tag images in the Media Library using the new "Gallery Categories" taxonomy.
2. Place a Divi Gallery module on your page as you normally would.
3. Add the `[dfg_gallery_filters]` shortcode above the gallery (via a Divi Code module).
4. Visitors click filter buttons to show/hide images by category, with smooth fade transitions.

**Key features:**

* Category tagging directly in WordPress Media Library
* Filter buttons match Divi's native filterable portfolio styling for visual consistency
* Vanilla JavaScript — no jQuery dependency on the front end
* URL parameter support (`?filter=category-slug`) for shareable filtered views
* Mobile-friendly: filters scroll horizontally on small screens
* Accessible: ARIA attributes, keyboard navigation, reduced-motion support
* Built for Divi 5 specifically — uses modern hooks and DOM patterns

**Recipe documentation:**

The full build walkthrough is published as a recipe at https://16wells.github.io/divi-docs/recipes/divi5-filterable-gallery/

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via Plugins → Add New.
2. Activate the plugin through the Plugins screen.
3. Tag images in Media Library → Library (list view) → Gallery Categories column.
4. On any Divi page, add a Code module above your Gallery module containing: `[dfg_gallery_filters]`
5. Save and view the page.

== Frequently Asked Questions ==

= Does this work with Divi 4? =

No. This plugin uses Divi 5-specific hooks and conventions. For Divi 4, use the Filterable Portfolio module with the Projects custom post type.

= Will uninstalling delete my categories? =

No. Uninstalling removes the plugin code only. Your tagged images and categories are preserved. To remove all plugin data, use the "Reset All Plugin Data" button on the plugin settings page before uninstalling.

= Can I customize the filter button styling? =

Yes. The plugin settings page (Media → Filterable Gallery, available in version 1.1+) includes a custom CSS editor with a class reference panel. You can also override the active button color via the `--dfg-active-bg` CSS variable.

= Does it work with Divi's gallery lightbox? =

Yes. The plugin only toggles visibility on filtered items — it doesn't replace the gallery's rendering, so Divi's lightbox continues to work normally.

== Screenshots ==

1. Filter buttons above a Divi gallery
2. Gallery Categories metabox in the Media Library

== Changelog ==

= 1.2.5 =
* Fix maximize toggle: class reference panel now correctly shrinks to match the editor's height instead of overflowing into the preview area. Implementation pins reference's max-height to editor's measured height via JS, with a ResizeObserver to keep them in sync if the editor is resized.

= 1.2.4 =
* Settings page layout: live preview now sits in the same column as the CSS editor (stacked beneath it), with the class reference as a sidebar alongside both. Maximize button in the preview header expands the preview to span the full page width; class reference shrinks to match the editor's height. User preference is persisted across reloads.

= 1.2.3 =
* Fix gallery layout leaving gaps where filtered-out images used to be. Hidden items now use display:none so visible items reflow up to fill the grid. Trades the fade animation for correct layout (the right call — Divi's own Filterable Portfolio works the same way).

= 1.2.2 =
* Fix root cause of unsaved-changes indicator showing on page load: the HTML5 hidden attribute was being overridden by display:inline-flex on the indicator span. Adds an explicit [hidden] rule to admin.css.

= 1.2.1 =
* Fix dirty-state indicator firing on page load due to async CodeMirror init events. Tracking now activates on first keystroke or after a 250ms init-drain timeout, whichever comes first.

= 1.2.0 =
* Add live preview pane to the settings page — see CSS edits applied to a sample gallery in real time, before saving.
* Add Danger Zone with three-friction reset flow — type RESET to wipe all gallery categories, image taggings, and custom CSS.
* Fix dirty-state indicator firing on initial page load before any edits.
* Remove duplicate metabox code from the main plugin file (cleanup of dead Layer 1b code from 1.0.x).

= 1.1.0 =
* Add Media → Filterable Gallery settings page with CodeMirror CSS editor.
* Add class reference panel with click-to-copy selectors.
* Default CSS now seeded with theme-bullet fix on fresh installs.
* User CSS prints in <head> at priority 100, after plugin defaults.

= 1.0.2 =
* Fix output filter to match both et_pb_gallery_item and et_pb_gallery_image wrappers.
* Fix attachment taxonomy term counts (use _update_generic_term_count).

= 1.0.0 =
* Initial release
* Custom taxonomy on attachments
* Output filter for Divi Gallery module
* Filter shortcode with URL parameter support
* Vanilla JS frontend with accessibility support

== Upgrade Notice ==

= 1.2.5 =
Fixes the class reference sidebar overflowing the preview area when maximize is toggled. No breaking changes.

= 1.2.4 =
Settings page reorganized: live preview now stacks below the CSS editor in the same column, with a maximize button to expand it full-width. No breaking changes.

= 1.2.3 =
Fixes layout gaps where filtered-out images used to be. Visible images now reflow up to fill the grid. No breaking changes.

= 1.2.2 =
Actually fixes the unsaved-changes indicator showing on load — root cause was a CSS specificity issue, not JavaScript. No breaking changes.

= 1.2.1 =
Defensive JS fix for the unsaved-changes indicator (turned out the real cause was CSS — see 1.2.2).

= 1.2.0 =
Adds live preview pane and Danger Zone reset feature. No breaking changes.

= 1.1.0 =
Adds an admin settings page with custom CSS editor. No breaking changes.

= 1.0.0 =
Initial release.

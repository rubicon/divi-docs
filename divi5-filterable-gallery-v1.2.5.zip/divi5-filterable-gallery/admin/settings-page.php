<?php
/**
 * Filterable Gallery for Divi 5 — Admin Settings Page
 *
 * Handles the Media → Filterable Gallery settings screen:
 *   - Settings registration + sanitization
 *   - CodeMirror-powered CSS editor
 *   - Class reference panel with click-to-copy selectors
 *
 * Loaded only when is_admin() is true (see main plugin file).
 *
 * @package Divi5_Filterable_Gallery
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option key for the user's custom CSS.
 */
if ( ! defined( 'DFG_CSS_OPTION' ) ) {
	define( 'DFG_CSS_OPTION', 'dfg_custom_css' );
}

/**
 * Capability required to edit plugin settings.
 *
 * Filterable so site owners can lower (or raise) the bar.
 *
 * @return string
 */
function dfg_settings_capability() {
	return apply_filters( 'dfg_settings_capability', 'manage_options' );
}

/**
 * Default CSS seeded on activation (and shown when option is empty).
 *
 * Includes the bullet-marker fix so new installs work cleanly with
 * themes that style <ul> elements aggressively.
 *
 * @return string
 */
function dfg_default_custom_css() {
	$default = <<<CSS
/* Filterable Gallery — Custom CSS
 *
 * Your CSS here loads AFTER the plugin's default styles, so your rules
 * win the cascade naturally. !important is rarely needed.
 *
 * The Class Reference panel on the right lists every selector you can
 * target. Click any selector to copy it to your clipboard.
 */

/* Hide theme <ul> bullets on the filter row.
   Most themes apply list-style + padding to <ul>. The plugin renders a <ul>
   to mirror Divi's Filterable Portfolio convention, so we strip bullets here. */
.dfg-gallery-filters ul.clearfix,
.dfg-gallery-filters ul.clearfix li {
    list-style: none !important;
    padding-left: 0 !important;
    margin-left: 0 !important;
}
.dfg-gallery-filters ul.clearfix li::before,
.dfg-gallery-filters ul.clearfix li::marker {
    content: none !important;
    display: none !important;
}

/* Example: change the active button color
.dfg-gallery-filters {
    --dfg-active-bg: #2271b1;
}
*/
CSS;

	return apply_filters( 'dfg_default_custom_css', $default );
}

/**
 * Register the settings menu under Media.
 *
 * Hooked to admin_menu from the main plugin file.
 */
function dfg_register_settings_page() {
	add_submenu_page(
		'upload.php',                                   // Parent: Media
		__( 'Filterable Gallery Settings', 'divi5-filterable-gallery' ),     // <title>
		__( 'Filterable Gallery', 'divi5-filterable-gallery' ),              // Menu label
		dfg_settings_capability(),                      // Capability
		'dfg-settings',                                 // Menu slug
		'dfg_render_settings_page'                      // Render callback
	);
}

/**
 * Register the custom CSS option with the Settings API.
 *
 * Hooked to admin_init from the main plugin file.
 */
function dfg_register_settings() {
	register_setting(
		'dfg_settings_group',
		DFG_CSS_OPTION,
		array(
			'type'              => 'string',
			'description'       => __( 'Custom CSS for the Filterable Gallery plugin.', 'divi5-filterable-gallery' ),
			'sanitize_callback' => 'dfg_sanitize_custom_css',
			'show_in_rest'      => false,
			'default'           => dfg_default_custom_css(),
		)
	);
}

/**
 * Sanitize the custom CSS input.
 *
 * Why wp_strip_all_tags() and not wp_kses() or a CSS parser?
 * - CSS itself can't execute scripts.
 * - Stripping <script> / <style> / HTML defeats the only realistic
 *   injection vector (someone pasting a payload that escapes when echoed).
 * - The output is wrapped in a <style> block printed via esc_html(),
 *   which neutralizes any remaining angle brackets.
 * - Full CSS syntax (calc, var, url, media queries, @keyframes) is preserved.
 *
 * Capability check (manage_options by default) gates who can save in the
 * first place, so admins pasting their own CSS are trusted.
 *
 * @param string $input Raw CSS submitted by the user.
 * @return string Sanitized CSS.
 */
function dfg_sanitize_custom_css( $input ) {
	if ( ! is_string( $input ) ) {
		return '';
	}

	// Strip any HTML tags — CSS doesn't need them, and they're the only
	// real escape vector when this is later printed inside a <style> block.
	$clean = wp_strip_all_tags( $input );

	// Normalize Windows-style line endings for cleaner storage.
	$clean = str_replace( "\r\n", "\n", $clean );

	return $clean;
}

/**
 * Enqueue assets for the settings page only.
 *
 * Hooked to admin_enqueue_scripts from the main plugin file.
 *
 * @param string $hook Current admin page hook suffix.
 */
function dfg_enqueue_admin_assets( $hook ) {
	// Bail unless we're on our settings page.
	// add_submenu_page() under upload.php returns hook 'media_page_dfg-settings'.
	if ( 'media_page_dfg-settings' !== $hook ) {
		return;
	}

	// Frontend filter styles — enqueued on the settings page so the live
	// preview pane renders with the plugin's actual default styling. The
	// user's custom CSS then layers on top via the dfg-preview-css <style>
	// element injected at runtime.
	wp_enqueue_style(
		'dfg-filter',
		plugins_url( 'assets/filter.css', dirname( __FILE__ ) ),
		array(),
		defined( 'DFG_VERSION' ) ? DFG_VERSION : '1.2.0'
	);

	// Admin stylesheet for the layout (editor, reference, preview, danger zone, modal).
	wp_enqueue_style(
		'dfg-admin',
		plugins_url( 'assets/admin.css', dirname( __FILE__ ) ),
		array( 'dfg-filter' ),
		defined( 'DFG_VERSION' ) ? DFG_VERSION : '1.2.0'
	);

	// AJAX config for the Danger Zone reset flow. Available regardless of
	// whether CodeMirror loads, since the reset is independent of the editor.
	wp_localize_script(
		'jquery',
		'dfgAdminConfig',
		array(
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'resetNonce' => wp_create_nonce( 'dfg_reset_nonce' ),
			'i18n'       => array(
				'confirmPhrase' => 'RESET',
				'resetting'     => __( 'Resetting…', 'divi5-filterable-gallery' ),
				'reloadingMsg'  => __( ' Reloading page…', 'divi5-filterable-gallery' ),
				'networkError'  => __( 'Network error. Please try again.', 'divi5-filterable-gallery' ),
				'genericError'  => __( 'Reset failed.', 'divi5-filterable-gallery' ),
			),
		)
	);

	// WordPress core's bundled CodeMirror, configured for CSS.
	$cm_settings = wp_enqueue_code_editor(
		array(
			'type' => 'text/css',
		)
	);

	// wp_enqueue_code_editor returns false when the user has disabled the
	// rich code editor in their profile. The textarea degrades gracefully.
	if ( false === $cm_settings ) {
		return;
	}

	wp_localize_script(
		'jquery',
		'dfgEditorSettings',
		$cm_settings
	);
}

/**
 * Render the settings page.
 *
 * Two-pane layout: CodeMirror editor on the left, class reference on the right.
 */
function dfg_render_settings_page() {
	if ( ! current_user_can( dfg_settings_capability() ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'divi5-filterable-gallery' ) );
	}

	$css = get_option( DFG_CSS_OPTION, dfg_default_custom_css() );
	?>
	<div class="wrap dfg-settings-wrap">
		<h1>
			<?php esc_html_e( 'Filterable Gallery for Divi 5', 'divi5-filterable-gallery' ); ?>
			<span class="dfg-version">v<?php echo esc_html( defined( 'DFG_VERSION' ) ? DFG_VERSION : '1.1.0' ); ?></span>
		</h1>

		<p class="dfg-lede">
			<?php esc_html_e( 'Custom CSS below loads after the plugin\'s default styles, so your rules win the cascade. Use the class reference on the right to find selectors — click any of them to copy.', 'divi5-filterable-gallery' ); ?>
		</p>

		<form method="post" action="options.php" id="dfg-settings-form">
			<?php settings_fields( 'dfg_settings_group' ); ?>

			<div class="dfg-toolbar">
				<?php submit_button(
					__( 'Save Changes', 'divi5-filterable-gallery' ),
					'primary',
					'submit',
					false,
					array( 'id' => 'dfg-save-button' )
				); ?>
				<span id="dfg-dirty-indicator" class="dfg-dirty-indicator" hidden>
					<span class="dashicons dashicons-warning" aria-hidden="true"></span>
					<?php esc_html_e( 'Unsaved changes', 'divi5-filterable-gallery' ); ?>
				</span>
				<span id="dfg-saved-indicator" class="dfg-saved-indicator" hidden>
					<span class="dashicons dashicons-yes" aria-hidden="true"></span>
					<?php esc_html_e( 'Saved', 'divi5-filterable-gallery' ); ?>
				</span>
			</div>

			<div class="dfg-panes">

				<!-- LEFT PANE: CodeMirror editor -->
				<div class="dfg-pane dfg-pane-editor">
					<label for="dfg_custom_css" class="screen-reader-text">
						<?php esc_html_e( 'Custom CSS', 'divi5-filterable-gallery' ); ?>
					</label>
					<textarea
						id="dfg_custom_css"
						name="<?php echo esc_attr( DFG_CSS_OPTION ); ?>"
						rows="24"
						cols="80"
						class="large-text code"
						spellcheck="false"
						autocomplete="off"
					><?php echo esc_textarea( $css ); ?></textarea>
				</div>

				<!-- RIGHT PANE: class reference -->
				<aside class="dfg-pane dfg-pane-reference" aria-labelledby="dfg-reference-heading">
					<h2 id="dfg-reference-heading"><?php esc_html_e( 'Class Reference', 'divi5-filterable-gallery' ); ?></h2>
					<p class="dfg-reference-help">
						<?php esc_html_e( 'Click any selector to copy.', 'divi5-filterable-gallery' ); ?>
					</p>

					<dl class="dfg-reference-list">
						<?php foreach ( dfg_class_reference() as $entry ) : ?>
							<dt>
								<button
									type="button"
									class="dfg-copy-selector"
									data-selector="<?php echo esc_attr( $entry['selector'] ); ?>"
									aria-label="<?php
										/* translators: %s is the CSS selector being copied. */
										echo esc_attr( sprintf( __( 'Copy selector %s', 'divi5-filterable-gallery' ), $entry['selector'] ) );
									?>"
								>
									<code><?php echo esc_html( $entry['selector'] ); ?></code>
									<span class="dfg-copy-icon dashicons dashicons-clipboard" aria-hidden="true"></span>
								</button>
							</dt>
							<dd><?php echo esc_html( $entry['description'] ); ?></dd>
						<?php endforeach; ?>
					</dl>

					<div class="dfg-reference-footer">
						<p>
							<?php
							echo wp_kses(
								/* translators: %s is the shortcode tag. */
								sprintf(
									__( 'Add the filter UI to any page with the %s shortcode.', 'divi5-filterable-gallery' ),
									'<code>[dfg_gallery_filters]</code>'
								),
								array( 'code' => array() )
							);
							?>
						</p>
					</div>
				</aside>

				<!-- =====================================================
				     LIVE PREVIEW PANE — sits in the same column as the
				     editor by default; can be maximized to span the full
				     width via the toggle button in its header.
				     ===================================================== -->
				<section class="dfg-pane dfg-pane-preview" aria-labelledby="dfg-preview-heading">
					<header class="dfg-preview-header">
						<h2 id="dfg-preview-heading"><?php esc_html_e( 'Live Preview', 'divi5-filterable-gallery' ); ?></h2>
						<button
							type="button"
							class="button dfg-preview-toggle"
							id="dfg-preview-toggle"
							aria-pressed="false"
							aria-label="<?php esc_attr_e( 'Maximize preview', 'divi5-filterable-gallery' ); ?>"
							title="<?php esc_attr_e( 'Maximize preview', 'divi5-filterable-gallery' ); ?>"
						>
							<span class="dashicons dashicons-fullscreen-alt" aria-hidden="true"></span>
							<span class="screen-reader-text"><?php esc_html_e( 'Maximize preview', 'divi5-filterable-gallery' ); ?></span>
						</button>
					</header>
					<p class="dfg-preview-help">
						<?php esc_html_e( 'Click filter buttons below to test interactions. Your CSS edits apply here in real time before saving.', 'divi5-filterable-gallery' ); ?>
					</p>

					<div class="dfg-preview-stage">
						<!-- Mock filter UI — uses real plugin classes so user CSS targets it correctly -->
						<div class="dfg-gallery-filters">
							<ul class="clearfix">
								<li class="dfg-filter active">
									<a href="#" data-filter="all"><?php esc_html_e( 'All', 'divi5-filterable-gallery' ); ?> <span class="dfg-count">(6)</span></a>
								</li>
								<li class="dfg-filter">
									<a href="#" data-filter="landscape"><?php esc_html_e( 'Landscape', 'divi5-filterable-gallery' ); ?> <span class="dfg-count">(3)</span></a>
								</li>
								<li class="dfg-filter">
									<a href="#" data-filter="portrait"><?php esc_html_e( 'Portrait', 'divi5-filterable-gallery' ); ?> <span class="dfg-count">(2)</span></a>
								</li>
								<li class="dfg-filter">
									<a href="#" data-filter="macro"><?php esc_html_e( 'Macro', 'divi5-filterable-gallery' ); ?> <span class="dfg-count">(1)</span></a>
								</li>
							</ul>
						</div>

						<!-- Mock gallery items — use Divi's classes so user CSS for .et_pb_gallery_item.dfg-hidden works -->
						<div class="dfg-preview-grid">
							<div class="et_pb_gallery_item" data-categories="landscape">
								<div class="et_pb_gallery_image landscape">A · Landscape</div>
							</div>
							<div class="et_pb_gallery_item" data-categories="portrait">
								<div class="et_pb_gallery_image portrait">B · Portrait</div>
							</div>
							<div class="et_pb_gallery_item" data-categories="landscape,macro">
								<div class="et_pb_gallery_image landscape">C · Landscape + Macro</div>
							</div>
							<div class="et_pb_gallery_item" data-categories="portrait">
								<div class="et_pb_gallery_image portrait">D · Portrait</div>
							</div>
							<div class="et_pb_gallery_item" data-categories="landscape">
								<div class="et_pb_gallery_image landscape">E · Landscape</div>
							</div>
							<div class="et_pb_gallery_item" data-categories="landscape">
								<div class="et_pb_gallery_image landscape">F · Landscape</div>
							</div>
						</div>
					</div>
				</section>

			</div><!-- .dfg-panes -->

		</form>

		<!-- =====================================================
		     DANGER ZONE — outside the settings form
		     ===================================================== -->
		<section class="dfg-danger-zone" aria-labelledby="dfg-danger-heading">
			<h2 id="dfg-danger-heading"><?php esc_html_e( 'Danger Zone', 'divi5-filterable-gallery' ); ?></h2>
			<div class="dfg-danger-card">
				<div class="dfg-danger-text">
					<h3><?php esc_html_e( 'Reset all plugin data', 'divi5-filterable-gallery' ); ?></h3>
					<p><?php esc_html_e( 'Permanently delete all gallery categories, image-to-category assignments, and your saved custom CSS. The plugin keeps working — you just get a clean slate.', 'divi5-filterable-gallery' ); ?></p>
				</div>
				<button type="button" class="button dfg-danger-button" id="dfg-reset-trigger">
					<?php esc_html_e( 'Reset All Plugin Data', 'divi5-filterable-gallery' ); ?>
				</button>
			</div>
		</section>

	</div><!-- .wrap -->

	<!-- =====================================================
	     RESET CONFIRMATION MODAL
	     ===================================================== -->
	<div class="dfg-modal-overlay" id="dfg-reset-modal" hidden>
		<div class="dfg-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="dfg-modal-title">
			<h2 id="dfg-modal-title"><?php esc_html_e( 'Reset all plugin data?', 'divi5-filterable-gallery' ); ?></h2>
			<p><?php esc_html_e( 'This will permanently delete:', 'divi5-filterable-gallery' ); ?></p>
			<ul class="dfg-modal-deletion-list">
				<li><?php esc_html_e( 'All Gallery Category terms', 'divi5-filterable-gallery' ); ?></li>
				<li><?php esc_html_e( 'All image-to-category assignments', 'divi5-filterable-gallery' ); ?></li>
				<li><?php esc_html_e( 'Your saved custom CSS (resets to default seed)', 'divi5-filterable-gallery' ); ?></li>
				<li><?php esc_html_e( 'All other plugin options', 'divi5-filterable-gallery' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'The plugin remains active. You can rebuild your taxonomy and customizations from scratch.', 'divi5-filterable-gallery' ); ?></p>
			<p class="dfg-modal-confirm-label">
				<?php
				echo wp_kses(
					/* translators: %s is the literal phrase RESET that the user must type. */
					sprintf( __( 'Type %s below to confirm:', 'divi5-filterable-gallery' ), '<strong>RESET</strong>' ),
					array( 'strong' => array() )
				);
				?>
			</p>
			<input type="text" id="dfg-reset-confirm" autocomplete="off" spellcheck="false" aria-label="<?php esc_attr_e( 'Type RESET to confirm', 'divi5-filterable-gallery' ); ?>" />
			<div class="dfg-modal-actions">
				<button type="button" class="button" id="dfg-reset-cancel">
					<?php esc_html_e( 'Cancel', 'divi5-filterable-gallery' ); ?>
				</button>
				<button type="button" class="button dfg-danger-button" id="dfg-reset-execute" disabled>
					<?php esc_html_e( 'Yes, Reset Everything', 'divi5-filterable-gallery' ); ?>
				</button>
			</div>
			<div class="dfg-modal-status" id="dfg-reset-status" hidden></div>
		</div>
	</div>

	<script type="text/javascript">
	(function() {
		'use strict';

		var saveButton  = document.getElementById( 'dfg-save-button' );
		var dirtyEl     = document.getElementById( 'dfg-dirty-indicator' );
		var savedEl     = document.getElementById( 'dfg-saved-indicator' );
		var textarea    = document.getElementById( 'dfg_custom_css' );
		var form        = document.getElementById( 'dfg-settings-form' );
		var initialCSS  = textarea ? textarea.value : '';
		var isDirty     = false;
		var isSubmitting = false;

		// --------------------------------------------------------------
		// 1. CodeMirror init
		// --------------------------------------------------------------
		var editor = null;
		if ( typeof window.wp !== 'undefined'
			&& typeof window.wp.codeEditor !== 'undefined'
			&& typeof window.dfgEditorSettings !== 'undefined'
			&& window.dfgEditorSettings ) {

			editor = window.wp.codeEditor.initialize( textarea, window.dfgEditorSettings );

			if ( editor && editor.codemirror ) {
				// CodeMirror fires "change" events during init — both
				// synchronously (when setValue runs internally) and
				// asynchronously (when normalization or refresh fires later).
				// We can't reliably catch all init events at the moment of
				// initialize() return, so we use a tracking flag instead:
				//
				//   - Until trackingActive is true, every change is treated
				//     as init noise. We resync the baseline against the
				//     current editor value and DO NOT flag dirty.
				//
				//   - trackingActive flips true on the first user keystroke
				//     OR after a 250ms timeout, whichever comes first.
				//     Keystrokes fire BEFORE their associated change event,
				//     so the baseline is locked just before the first real
				//     change is recorded.
				var trackingActive = false;

				function lockBaselineAndTrack() {
					if ( trackingActive ) {
						return;
					}
					initialCSS = editor.codemirror.getValue();
					setDirty( false );
					trackingActive = true;
				}

				editor.codemirror.on( 'change', function() {
					if ( ! trackingActive ) {
						// Init-time noise — keep baseline current, no dirty flag.
						initialCSS = editor.codemirror.getValue();
						return;
					}
					setDirty( editor.codemirror.getValue() !== initialCSS );
				});

				// First user keystroke locks the baseline (fires before change).
				editor.codemirror.on( 'keydown', lockBaselineAndTrack );

				// Belt-and-suspenders: lock baseline once init events have
				// had time to drain. 250ms is well below any realistic
				// human typing latency, so this won't race with the user.
				setTimeout( lockBaselineAndTrack, 250 );
			}
		} else if ( textarea ) {
			// Fallback: plain textarea dirty tracking.
			textarea.addEventListener( 'input', function() {
				setDirty( textarea.value !== initialCSS );
			});
		}

		// --------------------------------------------------------------
		// 2. Dirty-state UI + beforeunload guard
		// --------------------------------------------------------------
		function setDirty( dirty ) {
			isDirty = dirty;
			if ( dirtyEl ) {
				dirtyEl.hidden = ! dirty;
			}
			if ( savedEl ) {
				savedEl.hidden = true;
			}
		}

		window.addEventListener( 'beforeunload', function( e ) {
			if ( isDirty && ! isSubmitting ) {
				// Modern browsers ignore the custom message but require a return value.
				e.preventDefault();
				e.returnValue = '';
				return '';
			}
		});

		if ( form ) {
			form.addEventListener( 'submit', function() {
				// Sync CodeMirror back to the textarea before submit (CodeMirror does this automatically via save()).
				if ( editor && editor.codemirror ) {
					editor.codemirror.save();
				}
				isSubmitting = true;
			});
		}

		// Show "Saved" badge briefly when arriving with settings-updated=true.
		if ( window.location.search.indexOf( 'settings-updated=true' ) !== -1 && savedEl ) {
			savedEl.hidden = false;
			setTimeout( function() {
				savedEl.hidden = true;
			}, 4000 );
		}

		// --------------------------------------------------------------
		// 3. Click-to-copy selectors
		// --------------------------------------------------------------
		var copyButtons = document.querySelectorAll( '.dfg-copy-selector' );
		Array.prototype.forEach.call( copyButtons, function( btn ) {
			btn.addEventListener( 'click', function() {
				var selector = btn.getAttribute( 'data-selector' ) || '';
				copyToClipboard( selector ).then( function() {
					flashCopied( btn );
				}).catch( function() {
					// Fallback: select-and-prompt user to copy manually.
					alert( selector );
				});
			});
		});

		function copyToClipboard( text ) {
			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				return navigator.clipboard.writeText( text );
			}
			// Legacy fallback for older browsers.
			return new Promise( function( resolve, reject ) {
				try {
					var ta = document.createElement( 'textarea' );
					ta.value = text;
					ta.setAttribute( 'readonly', '' );
					ta.style.position = 'absolute';
					ta.style.left = '-9999px';
					document.body.appendChild( ta );
					ta.select();
					document.execCommand( 'copy' );
					document.body.removeChild( ta );
					resolve();
				} catch ( err ) {
					reject( err );
				}
			});
		}

		function flashCopied( btn ) {
			btn.classList.add( 'dfg-copied' );
			var originalLabel = btn.getAttribute( 'aria-label' );
			btn.setAttribute( 'aria-label', '<?php echo esc_js( __( 'Copied!', 'divi5-filterable-gallery' ) ); ?>' );
			setTimeout( function() {
				btn.classList.remove( 'dfg-copied' );
				if ( originalLabel ) {
					btn.setAttribute( 'aria-label', originalLabel );
				}
			}, 1200 );
		}

		// --------------------------------------------------------------
		// 4. Live Preview — inject editor CSS in real time
		// --------------------------------------------------------------
		// Create a dedicated <style> element and append it to <head>. We update
		// its textContent on every editor change. The user's CSS targets the
		// same .dfg-* and .et_pb_gallery_item selectors used in the preview
		// stage, so visual changes apply immediately.
		var previewStyleEl = document.createElement( 'style' );
		previewStyleEl.id = 'dfg-preview-css';
		document.head.appendChild( previewStyleEl );

		function applyPreviewCSS( css ) {
			previewStyleEl.textContent = css || '';
		}

		// Initial paint and ongoing updates.
		if ( editor && editor.codemirror ) {
			applyPreviewCSS( editor.codemirror.getValue() );
			editor.codemirror.on( 'change', function() {
				applyPreviewCSS( editor.codemirror.getValue() );
			});
		} else if ( textarea ) {
			applyPreviewCSS( textarea.value );
			textarea.addEventListener( 'input', function() {
				applyPreviewCSS( textarea.value );
			});
		}

		// --------------------------------------------------------------
		// 5. Live Preview — interactive filter buttons (mock behavior)
		// --------------------------------------------------------------
		// Mirrors the frontend filter.js logic at small scale so the preview
		// behaves like the real thing — clicking a filter highlights it and
		// hides non-matching items via the .dfg-hidden class.
		var previewFilterLinks = document.querySelectorAll( '.dfg-pane-preview .dfg-gallery-filters a' );
		var previewItems = document.querySelectorAll( '.dfg-pane-preview .et_pb_gallery_item' );

		Array.prototype.forEach.call( previewFilterLinks, function( link ) {
			link.addEventListener( 'click', function( e ) {
				e.preventDefault();
				var filter = link.getAttribute( 'data-filter' ) || 'all';

				// Update active state — match both li.active and a.active patterns
				// since the plugin's CSS supports either selector.
				Array.prototype.forEach.call( previewFilterLinks, function( other ) {
					other.classList.remove( 'active' );
					if ( other.parentElement ) {
						other.parentElement.classList.remove( 'active' );
					}
				});
				link.classList.add( 'active' );
				if ( link.parentElement ) {
					link.parentElement.classList.add( 'active' );
				}

				// Show/hide items based on data-categories
				Array.prototype.forEach.call( previewItems, function( item ) {
					var raw = item.getAttribute( 'data-categories' ) || '';
					var categories = raw.split( ',' );
					if ( filter === 'all' || categories.indexOf( filter ) !== -1 ) {
						item.classList.remove( 'dfg-hidden' );
					} else {
						item.classList.add( 'dfg-hidden' );
					}
				});
			});
		});

		// --------------------------------------------------------------
		// 6. Danger Zone — modal flow with type-to-confirm
		// --------------------------------------------------------------
		var dangerTrigger    = document.getElementById( 'dfg-reset-trigger' );
		var resetModal       = document.getElementById( 'dfg-reset-modal' );
		var resetConfirmInp  = document.getElementById( 'dfg-reset-confirm' );
		var resetExecuteBtn  = document.getElementById( 'dfg-reset-execute' );
		var resetCancelBtn   = document.getElementById( 'dfg-reset-cancel' );
		var resetStatusEl    = document.getElementById( 'dfg-reset-status' );
		var adminConfig      = window.dfgAdminConfig || null;

		if ( dangerTrigger && resetModal && adminConfig ) {

			function openResetModal() {
				resetModal.hidden = false;
				resetConfirmInp.value = '';
				resetExecuteBtn.disabled = true;
				resetCancelBtn.disabled = false;
				resetStatusEl.hidden = true;
				resetStatusEl.className = 'dfg-modal-status';
				resetStatusEl.textContent = '';
				document.body.classList.add( 'dfg-modal-open' );
				// Defer focus to next tick so the modal is fully painted.
				setTimeout( function() {
					resetConfirmInp.focus();
				}, 30 );
			}

			function closeResetModal() {
				resetModal.hidden = true;
				document.body.classList.remove( 'dfg-modal-open' );
				dangerTrigger.focus();
			}

			dangerTrigger.addEventListener( 'click', openResetModal );
			resetCancelBtn.addEventListener( 'click', closeResetModal );

			// Click outside the dialog closes the modal.
			resetModal.addEventListener( 'click', function( e ) {
				if ( e.target === resetModal ) {
					closeResetModal();
				}
			});

			// Escape key closes the modal.
			document.addEventListener( 'keydown', function( e ) {
				if ( e.key === 'Escape' && ! resetModal.hidden ) {
					closeResetModal();
				}
			});

			// Enable the destructive button only when input matches "RESET" exactly.
			resetConfirmInp.addEventListener( 'input', function() {
				resetExecuteBtn.disabled = ( resetConfirmInp.value !== adminConfig.i18n.confirmPhrase );
			});

			// Enter key in the input triggers execute (when enabled), not form submit.
			resetConfirmInp.addEventListener( 'keydown', function( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();
					if ( ! resetExecuteBtn.disabled ) {
						resetExecuteBtn.click();
					}
				}
			});

			// Execute the reset via AJAX.
			resetExecuteBtn.addEventListener( 'click', function() {
				if ( resetConfirmInp.value !== adminConfig.i18n.confirmPhrase ) {
					return;
				}

				resetExecuteBtn.disabled = true;
				resetCancelBtn.disabled = true;
				resetStatusEl.hidden = false;
				resetStatusEl.className = 'dfg-modal-status dfg-modal-status-pending';
				resetStatusEl.textContent = adminConfig.i18n.resetting;

				var formData = new FormData();
				formData.append( 'action', 'dfg_reset_plugin_data' );
				formData.append( 'nonce', adminConfig.resetNonce );
				formData.append( 'confirm', resetConfirmInp.value );

				fetch( adminConfig.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: formData
				}).then( function( response ) {
					return response.json().then( function( data ) {
						return { ok: response.ok, data: data };
					});
				}).then( function( result ) {
					if ( result.data && result.data.success ) {
						resetStatusEl.className = 'dfg-modal-status dfg-modal-status-success';
						resetStatusEl.textContent = result.data.data.message + adminConfig.i18n.reloadingMsg;
						// Bypass the beforeunload dirty guard during the reload.
						isSubmitting = true;
						setTimeout( function() {
							window.location.reload();
						}, 1500 );
					} else {
						var msg = ( result.data && result.data.data && result.data.data.message )
							? result.data.data.message
							: adminConfig.i18n.genericError;
						resetStatusEl.className = 'dfg-modal-status dfg-modal-status-error';
						resetStatusEl.textContent = msg;
						resetExecuteBtn.disabled = false;
						resetCancelBtn.disabled = false;
					}
				}).catch( function() {
					resetStatusEl.className = 'dfg-modal-status dfg-modal-status-error';
					resetStatusEl.textContent = adminConfig.i18n.networkError;
					resetExecuteBtn.disabled = false;
					resetCancelBtn.disabled = false;
				});
			});
		}

		// --------------------------------------------------------------
		// 7. Live Preview maximize/restore toggle
		// --------------------------------------------------------------
		// Toggles the .dfg-preview-maximized class on the .dfg-panes
		// container, which the CSS uses to switch grid-template-areas.
		// User preference is persisted in localStorage so the choice
		// sticks across reloads. Falls back gracefully if storage is
		// blocked (private mode, etc.).
		var previewToggleBtn = document.getElementById( 'dfg-preview-toggle' );
		var panesContainer   = document.querySelector( '.dfg-panes' );
		var editorPane       = document.querySelector( '.dfg-pane-editor' );
		var referencePane    = document.querySelector( '.dfg-pane-reference' );
		var STORAGE_KEY      = 'dfg-preview-maximized';

		function syncReferenceHeightToEditor() {
			// Pin the reference panel's max-height to whatever the editor
			// is currently rendering at, so it visually shrinks to match
			// row 1 instead of overflowing into the preview area below.
			// Only applies in maximized mode.
			if ( ! referencePane || ! editorPane ) {
				return;
			}
			if ( panesContainer.classList.contains( 'dfg-preview-maximized' ) ) {
				referencePane.style.maxHeight = editorPane.offsetHeight + 'px';
			}
		}

		function setPreviewMaximized( maximized ) {
			if ( ! previewToggleBtn || ! panesContainer ) {
				return;
			}
			panesContainer.classList.toggle( 'dfg-preview-maximized', maximized );
			previewToggleBtn.setAttribute( 'aria-pressed', maximized ? 'true' : 'false' );

			// Reference panel constraints — apply on maximize, clear on restore.
			// position:sticky + the default max-height: calc(100vh - 110px)
			// would otherwise keep the panel rendering at viewport height
			// regardless of its grid cell, overlapping the preview.
			if ( referencePane ) {
				if ( maximized ) {
					// Override sticky and pin max-height to editor's height.
					referencePane.style.position = 'static';
					referencePane.style.top = 'auto';
					if ( editorPane ) {
						referencePane.style.maxHeight = editorPane.offsetHeight + 'px';
					}
				} else {
					// Clear inline overrides; CSS sticky behavior resumes.
					referencePane.style.position = '';
					referencePane.style.top = '';
					referencePane.style.maxHeight = '';
				}
			}

			var icon = previewToggleBtn.querySelector( '.dashicons' );
			if ( icon ) {
				if ( maximized ) {
					icon.classList.remove( 'dashicons-fullscreen-alt' );
					icon.classList.add( 'dashicons-fullscreen-exit-alt' );
				} else {
					icon.classList.remove( 'dashicons-fullscreen-exit-alt' );
					icon.classList.add( 'dashicons-fullscreen-alt' );
				}
			}

			var label = maximized
				? '<?php echo esc_js( __( 'Restore preview to default size', 'divi5-filterable-gallery' ) ); ?>'
				: '<?php echo esc_js( __( 'Maximize preview', 'divi5-filterable-gallery' ) ); ?>';
			previewToggleBtn.setAttribute( 'aria-label', label );
			previewToggleBtn.setAttribute( 'title', label );

			// Tell CodeMirror to recalculate its layout — when the grid
			// shifts, the editor's available width changes and CM needs
			// to redraw scrollbars and gutter measurements. Then re-sync
			// the reference height in case CodeMirror's refresh changed
			// the editor pane's measured height.
			if ( editor && editor.codemirror ) {
				setTimeout( function() {
					editor.codemirror.refresh();
					syncReferenceHeightToEditor();
				}, 200 );
			}
		}

		if ( previewToggleBtn && panesContainer ) {
			previewToggleBtn.addEventListener( 'click', function() {
				var nowMaximized = ! panesContainer.classList.contains( 'dfg-preview-maximized' );
				setPreviewMaximized( nowMaximized );

				try {
					window.localStorage.setItem( STORAGE_KEY, nowMaximized ? '1' : '0' );
				} catch ( e ) {
					// localStorage blocked (private mode, etc.) — no-op
				}
			});

			// Restore saved preference on page load.
			try {
				if ( window.localStorage.getItem( STORAGE_KEY ) === '1' ) {
					setPreviewMaximized( true );
				}
			} catch ( e ) {
				// localStorage blocked — start in default state
			}

			// Keep reference panel matched to editor height when the
			// editor changes size (window resize, CodeMirror vertical
			// resize handle, etc.). ResizeObserver is supported in all
			// modern browsers; fall back to window resize if missing.
			if ( typeof ResizeObserver !== 'undefined' && editorPane ) {
				var ro = new ResizeObserver( syncReferenceHeightToEditor );
				ro.observe( editorPane );
			} else {
				window.addEventListener( 'resize', syncReferenceHeightToEditor );
			}
		}

	})();
	</script>
	<?php
}

/**
 * The selectors documented in the right-hand reference panel.
 *
 * Filterable so site owners and downstream plugins can add their own.
 *
 * @return array<int,array{selector:string,description:string}>
 */
function dfg_class_reference() {
	$reference = array(
		array(
			'selector'    => '.dfg-gallery-filters',
			'description' => __( 'Wrapper around the entire filter UI. Set --dfg-active-bg here, or style margins, padding, and alignment.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters ul',
			'description' => __( 'The filter list. Default is a centered inline-flex with 8px gap. Override flex-wrap, justify-content, or gap here.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-filter',
			'description' => __( 'Each filter list item (the <li>). Use for vertical spacing or row separators.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a',
			'description' => __( 'The clickable button inside each filter. Style typography, padding, background color, border, and radius here.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a:hover',
			'description' => __( 'Hover state for filter buttons. Use for hover background or color shifts.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a:focus-visible',
			'description' => __( 'Keyboard-only focus ring on filter buttons. Default is a 2px outline in --dfg-active-bg.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a.active',
			'description' => __( 'The active (currently selected) filter button. Default background is --dfg-active-bg with white text.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-count',
			'description' => __( 'The image-count badge inside each filter button (e.g. "Landscape (12)"). Style font weight, size, or hide it entirely.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.et_pb_gallery_item.dfg-hidden',
			'description' => __( 'Gallery items currently filtered out. Default is display:none with !important so the grid reflows. Avoid overriding unless you understand the layout reflow trade-off.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '--dfg-active-bg',
			'description' => __( 'CSS custom property controlling the active button background and focus ring color. Default #2271b1. Set on .dfg-gallery-filters or :root.', 'divi5-filterable-gallery' ),
		),
	);

	return apply_filters( 'dfg_class_reference', $reference );
}


// =============================================================================
// AJAX Handler — Danger Zone Reset
// =============================================================================

/**
 * Handle the "Reset All Plugin Data" AJAX request.
 *
 * Three layers of protection (in addition to the user-facing modal flow):
 *   1. Nonce verification — prevents CSRF.
 *   2. Capability check — only users with manage_options can reset.
 *   3. Confirmation phrase — POST['confirm'] must equal 'RESET' exactly.
 *
 * On success, deletes all gallery_category terms (which automatically removes
 * attachment-to-term associations), wipes the custom CSS option, and re-seeds
 * the default CSS so the plugin remains functional.
 *
 * @return void Always exits via wp_send_json_success / wp_send_json_error.
 */
function dfg_handle_reset_request() {
	// 1. Nonce
	if ( ! check_ajax_referer( 'dfg_reset_nonce', 'nonce', false ) ) {
		wp_send_json_error(
			array( 'message' => __( 'Security check failed. Please reload the page and try again.', 'divi5-filterable-gallery' ) ),
			403
		);
	}

	// 2. Capability
	if ( ! current_user_can( dfg_settings_capability() ) ) {
		wp_send_json_error(
			array( 'message' => __( 'Permission denied.', 'divi5-filterable-gallery' ) ),
			403
		);
	}

	// 3. Confirmation phrase
	$confirm = isset( $_POST['confirm'] ) ? sanitize_text_field( wp_unslash( $_POST['confirm'] ) ) : '';
	if ( 'RESET' !== $confirm ) {
		wp_send_json_error(
			array( 'message' => __( 'Confirmation phrase did not match.', 'divi5-filterable-gallery' ) ),
			400
		);
	}

	// Delete all gallery_category terms.
	// wp_delete_term automatically removes the term from all attachments
	// (the wp_term_relationships table entries get cleaned up by core).
	$term_count = 0;
	if ( taxonomy_exists( DFG_TAXONOMY ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => DFG_TAXONOMY,
				'hide_empty' => false,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$deleted = wp_delete_term( $term->term_id, DFG_TAXONOMY );
				if ( ! is_wp_error( $deleted ) && $deleted ) {
					$term_count++;
				}
			}
		}
	}

	// Wipe the custom CSS option, then re-seed the default so the plugin
	// remains visually correct out of the box (no broken bullet markers, etc).
	delete_option( DFG_CSS_OPTION );
	add_option( DFG_CSS_OPTION, dfg_default_custom_css() );

	wp_send_json_success(
		array(
			'message' => sprintf(
				/* translators: %d is the number of category terms deleted. */
				_n(
					'Reset complete. %d category deleted, custom CSS restored to default.',
					'Reset complete. %d categories deleted, custom CSS restored to default.',
					$term_count,
					'divi5-filterable-gallery'
				),
				$term_count
			),
			'terms_deleted' => $term_count,
		)
	);
}
add_action( 'wp_ajax_dfg_reset_plugin_data', 'dfg_handle_reset_request' );

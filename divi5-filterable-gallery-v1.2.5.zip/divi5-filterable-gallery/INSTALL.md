# Quick Test Guide — Chunk 1

This is the foundation chunk. After installing, you'll have a working filterable gallery — but no admin settings page yet (that's Chunk 2). Test in this order so each phase verifies cleanly:

## Install

1. Upload the `divi5-filterable-gallery` folder to `wp-content/plugins/` on PVB staging
2. WP Admin → Plugins → Activate "Filterable Gallery for Divi 5"
3. Confirm no fatal errors, no PHP warnings in the activation flow

## Phase 2 verification — Taxonomy

1. Go to **Media → Library**, switch to **list view** (the small icon next to "Add New")
2. Confirm a "Gallery Categories" column appears
3. Above the list, confirm a "Filter by Gallery Category" dropdown appears
4. Click any image to edit it. Scroll to the right sidebar and confirm a "Gallery Categories" metabox is present
5. Add 3-5 categories in **Media → Gallery Categories** (left sidebar). For PVB use: corporate, private, celebrations, weddings, venue
6. Tag at least 8-10 images across these categories. Use multiple categories per image where appropriate

## Phase 3 verification — Output filter

1. Build a Divi 5 page with a Gallery module containing the tagged images
2. Save and view the page on the front end
3. Right-click → View Page Source (NOT inspect — we want the raw rendered HTML)
4. Search for `et_pb_gallery_item`
5. Each match should have a `data-categories="..."` attribute populated with the slugs of any categories assigned

If the data attribute is missing, check:
- Are the images actually tagged? (Re-check Media Library)
- Does the rendered `<img>` have a `wp-image-{ID}` class? (View source, search for `wp-image-`)
- Is a caching plugin serving stale HTML? (Clear all caches)

## Phase 4 verification — Shortcode

1. On the same Divi page, add a Code module ABOVE the Gallery module
2. Inside the Code module, paste: `[dfg_gallery_filters]`
3. Save and reload
4. You should see filter buttons rendered. The "All" button should be active (highlighted in WP admin blue)

If buttons don't appear:
- Confirm at least one term has at least one tagged image (the shortcode hides empty terms)
- Confirm the shortcode is in a Code module, not a Text module (Text modules sometimes mangle shortcodes)

## Phase 5 verification — Filter behavior

1. With the page loaded, click each filter button
2. Confirm:
   - Images animate to fade out when filtered
   - "All" restores everything
   - Active button moves with selection
   - URL updates to `?filter=corporate` (or whatever you click)
3. Manually add `?filter=weddings` to the URL and reload — page should land pre-filtered
4. On mobile (or browser DevTools mobile view), confirm filter buttons scroll horizontally if too many to fit
5. Tab through the buttons with keyboard — focus outline should be visible, Enter should activate

## What's NOT in this chunk

- Admin settings page (Media → Filterable Gallery menu)
- Custom CSS editor with CodeMirror
- CSS class reference panel
- Live preview pane
- Save protection / unsaved indicators
- Danger Zone reset feature
- "Divi 5 Global Variables" documentation

All of those land in Chunks 2 and 3.

## What to override for PVB right now

PVB uses Forest Green (#2D5016) for the active button. Until the admin settings page exists in Chunk 2, you can override by adding this to PVB's child theme `style.css` or via Divi → Theme Customizer → Additional CSS:

```css
:root {
    --dfg-active-bg: #2D5016;
}
```

This will be moved into the plugin's settings page CSS editor in Chunk 2.

## Reporting back

If everything passes, send "Chunk 1 OK" and I'll start writing Chunk 2 (admin settings page). If anything fails, send the specific phase number and I'll debug before moving forward.

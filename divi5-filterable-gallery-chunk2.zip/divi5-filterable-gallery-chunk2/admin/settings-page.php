<?php
/**
 * Filterable Gallery for Divi 5 — Admin Settings Page
 *
 * Handles the Media → Filterable Gallery settings screen:
 *   - Settings registration + sanitization
 *   - CodeMirror-powered CSS editor
 *   - Class reference panel with click-to-copy selectors
 *
 * Loaded only when is_admin() is true (see main plugin file).
 *
 * @package Divi5_Filterable_Gallery
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option key for the user's custom CSS.
 */
if ( ! defined( 'DFG_CSS_OPTION' ) ) {
	define( 'DFG_CSS_OPTION', 'dfg_custom_css' );
}

/**
 * Capability required to edit plugin settings.
 *
 * Filterable so site owners can lower (or raise) the bar.
 *
 * @return string
 */
function dfg_settings_capability() {
	return apply_filters( 'dfg_settings_capability', 'manage_options' );
}

/**
 * Default CSS seeded on activation (and shown when option is empty).
 *
 * Includes the bullet-marker fix so new installs work cleanly with
 * themes that style <ul> elements aggressively.
 *
 * @return string
 */
function dfg_default_custom_css() {
	$default = <<<CSS
/* Filterable Gallery — Custom CSS
 *
 * Your CSS here loads AFTER the plugin's default styles, so your rules
 * win the cascade naturally. !important is rarely needed.
 *
 * The Class Reference panel on the right lists every selector you can
 * target. Click any selector to copy it to your clipboard.
 */

/* Hide theme <ul> bullets on the filter row.
   Most themes apply list-style + padding to <ul>. The plugin renders a <ul>
   to mirror Divi's Filterable Portfolio convention, so we strip bullets here. */
.dfg-gallery-filters ul.clearfix,
.dfg-gallery-filters ul.clearfix li {
    list-style: none !important;
    padding-left: 0 !important;
    margin-left: 0 !important;
}
.dfg-gallery-filters ul.clearfix li::before,
.dfg-gallery-filters ul.clearfix li::marker {
    content: none !important;
    display: none !important;
}

/* Example: change the active button color
.dfg-gallery-filters {
    --dfg-active-bg: #2271b1;
}
*/
CSS;

	return apply_filters( 'dfg_default_custom_css', $default );
}

/**
 * Register the settings menu under Media.
 *
 * Hooked to admin_menu from the main plugin file.
 */
function dfg_register_settings_page() {
	add_submenu_page(
		'upload.php',                                   // Parent: Media
		__( 'Filterable Gallery Settings', 'divi5-filterable-gallery' ),     // <title>
		__( 'Filterable Gallery', 'divi5-filterable-gallery' ),              // Menu label
		dfg_settings_capability(),                      // Capability
		'dfg-settings',                                 // Menu slug
		'dfg_render_settings_page'                      // Render callback
	);
}

/**
 * Register the custom CSS option with the Settings API.
 *
 * Hooked to admin_init from the main plugin file.
 */
function dfg_register_settings() {
	register_setting(
		'dfg_settings_group',
		DFG_CSS_OPTION,
		array(
			'type'              => 'string',
			'description'       => __( 'Custom CSS for the Filterable Gallery plugin.', 'divi5-filterable-gallery' ),
			'sanitize_callback' => 'dfg_sanitize_custom_css',
			'show_in_rest'      => false,
			'default'           => dfg_default_custom_css(),
		)
	);
}

/**
 * Sanitize the custom CSS input.
 *
 * Why wp_strip_all_tags() and not wp_kses() or a CSS parser?
 * - CSS itself can't execute scripts.
 * - Stripping <script> / <style> / HTML defeats the only realistic
 *   injection vector (someone pasting a payload that escapes when echoed).
 * - The output is wrapped in a <style> block printed via esc_html(),
 *   which neutralizes any remaining angle brackets.
 * - Full CSS syntax (calc, var, url, media queries, @keyframes) is preserved.
 *
 * Capability check (manage_options by default) gates who can save in the
 * first place, so admins pasting their own CSS are trusted.
 *
 * @param string $input Raw CSS submitted by the user.
 * @return string Sanitized CSS.
 */
function dfg_sanitize_custom_css( $input ) {
	if ( ! is_string( $input ) ) {
		return '';
	}

	// Strip any HTML tags — CSS doesn't need them, and they're the only
	// real escape vector when this is later printed inside a <style> block.
	$clean = wp_strip_all_tags( $input );

	// Normalize Windows-style line endings for cleaner storage.
	$clean = str_replace( "\r\n", "\n", $clean );

	return $clean;
}

/**
 * Enqueue assets for the settings page only.
 *
 * Hooked to admin_enqueue_scripts from the main plugin file.
 *
 * @param string $hook Current admin page hook suffix.
 */
function dfg_enqueue_admin_assets( $hook ) {
	// Bail unless we're on our settings page.
	// add_submenu_page() under upload.php returns hook 'media_page_dfg-settings'.
	if ( 'media_page_dfg-settings' !== $hook ) {
		return;
	}

	// Admin stylesheet for the two-pane layout.
	wp_enqueue_style(
		'dfg-admin',
		plugins_url( 'assets/admin.css', dirname( __FILE__ ) ),
		array(),
		defined( 'DFG_VERSION' ) ? DFG_VERSION : '1.1.0'
	);

	// WordPress core's bundled CodeMirror, configured for CSS.
	$cm_settings = wp_enqueue_code_editor(
		array(
			'type' => 'text/css',
		)
	);

	// wp_enqueue_code_editor returns false when the user has disabled the
	// rich code editor in their profile. In that case CodeMirror won't load
	// and the textarea will degrade to a plain textarea — which is fine.
	if ( false === $cm_settings ) {
		return;
	}

	// Pass settings to our init script via a localized global.
	wp_localize_script(
		'jquery',
		'dfgEditorSettings',
		$cm_settings
	);
}

/**
 * Render the settings page.
 *
 * Two-pane layout: CodeMirror editor on the left, class reference on the right.
 */
function dfg_render_settings_page() {
	if ( ! current_user_can( dfg_settings_capability() ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'divi5-filterable-gallery' ) );
	}

	$css = get_option( DFG_CSS_OPTION, dfg_default_custom_css() );
	?>
	<div class="wrap dfg-settings-wrap">
		<h1>
			<?php esc_html_e( 'Filterable Gallery for Divi 5', 'divi5-filterable-gallery' ); ?>
			<span class="dfg-version">v<?php echo esc_html( defined( 'DFG_VERSION' ) ? DFG_VERSION : '1.1.0' ); ?></span>
		</h1>

		<p class="dfg-lede">
			<?php esc_html_e( 'Custom CSS below loads after the plugin\'s default styles, so your rules win the cascade. Use the class reference on the right to find selectors — click any of them to copy.', 'divi5-filterable-gallery' ); ?>
		</p>

		<form method="post" action="options.php" id="dfg-settings-form">
			<?php settings_fields( 'dfg_settings_group' ); ?>

			<div class="dfg-toolbar">
				<?php submit_button(
					__( 'Save Changes', 'divi5-filterable-gallery' ),
					'primary',
					'submit',
					false,
					array( 'id' => 'dfg-save-button' )
				); ?>
				<span id="dfg-dirty-indicator" class="dfg-dirty-indicator" hidden>
					<span class="dashicons dashicons-warning" aria-hidden="true"></span>
					<?php esc_html_e( 'Unsaved changes', 'divi5-filterable-gallery' ); ?>
				</span>
				<span id="dfg-saved-indicator" class="dfg-saved-indicator" hidden>
					<span class="dashicons dashicons-yes" aria-hidden="true"></span>
					<?php esc_html_e( 'Saved', 'divi5-filterable-gallery' ); ?>
				</span>
			</div>

			<div class="dfg-panes">

				<!-- LEFT PANE: CodeMirror editor -->
				<div class="dfg-pane dfg-pane-editor">
					<label for="dfg_custom_css" class="screen-reader-text">
						<?php esc_html_e( 'Custom CSS', 'divi5-filterable-gallery' ); ?>
					</label>
					<textarea
						id="dfg_custom_css"
						name="<?php echo esc_attr( DFG_CSS_OPTION ); ?>"
						rows="24"
						cols="80"
						class="large-text code"
						spellcheck="false"
						autocomplete="off"
					><?php echo esc_textarea( $css ); ?></textarea>
				</div>

				<!-- RIGHT PANE: class reference -->
				<aside class="dfg-pane dfg-pane-reference" aria-labelledby="dfg-reference-heading">
					<h2 id="dfg-reference-heading"><?php esc_html_e( 'Class Reference', 'divi5-filterable-gallery' ); ?></h2>
					<p class="dfg-reference-help">
						<?php esc_html_e( 'Click any selector to copy.', 'divi5-filterable-gallery' ); ?>
					</p>

					<dl class="dfg-reference-list">
						<?php foreach ( dfg_class_reference() as $entry ) : ?>
							<dt>
								<button
									type="button"
									class="dfg-copy-selector"
									data-selector="<?php echo esc_attr( $entry['selector'] ); ?>"
									aria-label="<?php
										/* translators: %s is the CSS selector being copied. */
										echo esc_attr( sprintf( __( 'Copy selector %s', 'divi5-filterable-gallery' ), $entry['selector'] ) );
									?>"
								>
									<code><?php echo esc_html( $entry['selector'] ); ?></code>
									<span class="dfg-copy-icon dashicons dashicons-clipboard" aria-hidden="true"></span>
								</button>
							</dt>
							<dd><?php echo esc_html( $entry['description'] ); ?></dd>
						<?php endforeach; ?>
					</dl>

					<div class="dfg-reference-footer">
						<p>
							<?php
							echo wp_kses(
								/* translators: %s is the shortcode tag. */
								sprintf(
									__( 'Add the filter UI to any page with the %s shortcode.', 'divi5-filterable-gallery' ),
									'<code>[dfg_gallery_filters]</code>'
								),
								array( 'code' => array() )
							);
							?>
						</p>
					</div>
				</aside>

			</div><!-- .dfg-panes -->
		</form>
	</div><!-- .wrap -->

	<script type="text/javascript">
	(function() {
		'use strict';

		var saveButton  = document.getElementById( 'dfg-save-button' );
		var dirtyEl     = document.getElementById( 'dfg-dirty-indicator' );
		var savedEl     = document.getElementById( 'dfg-saved-indicator' );
		var textarea    = document.getElementById( 'dfg_custom_css' );
		var form        = document.getElementById( 'dfg-settings-form' );
		var initialCSS  = textarea ? textarea.value : '';
		var isDirty     = false;
		var isSubmitting = false;

		// --------------------------------------------------------------
		// 1. CodeMirror init
		// --------------------------------------------------------------
		var editor = null;
		if ( typeof window.wp !== 'undefined'
			&& typeof window.wp.codeEditor !== 'undefined'
			&& typeof window.dfgEditorSettings !== 'undefined'
			&& window.dfgEditorSettings ) {

			editor = window.wp.codeEditor.initialize( textarea, window.dfgEditorSettings );

			if ( editor && editor.codemirror ) {
				editor.codemirror.on( 'change', function() {
					var current = editor.codemirror.getValue();
					setDirty( current !== initialCSS );
				});
			}
		} else if ( textarea ) {
			// Fallback: plain textarea dirty tracking.
			textarea.addEventListener( 'input', function() {
				setDirty( textarea.value !== initialCSS );
			});
		}

		// --------------------------------------------------------------
		// 2. Dirty-state UI + beforeunload guard
		// --------------------------------------------------------------
		function setDirty( dirty ) {
			isDirty = dirty;
			if ( dirtyEl ) {
				dirtyEl.hidden = ! dirty;
			}
			if ( savedEl ) {
				savedEl.hidden = true;
			}
		}

		window.addEventListener( 'beforeunload', function( e ) {
			if ( isDirty && ! isSubmitting ) {
				// Modern browsers ignore the custom message but require a return value.
				e.preventDefault();
				e.returnValue = '';
				return '';
			}
		});

		if ( form ) {
			form.addEventListener( 'submit', function() {
				// Sync CodeMirror back to the textarea before submit (CodeMirror does this automatically via save()).
				if ( editor && editor.codemirror ) {
					editor.codemirror.save();
				}
				isSubmitting = true;
			});
		}

		// Show "Saved" badge briefly when arriving with settings-updated=true.
		if ( window.location.search.indexOf( 'settings-updated=true' ) !== -1 && savedEl ) {
			savedEl.hidden = false;
			setTimeout( function() {
				savedEl.hidden = true;
			}, 4000 );
		}

		// --------------------------------------------------------------
		// 3. Click-to-copy selectors
		// --------------------------------------------------------------
		var copyButtons = document.querySelectorAll( '.dfg-copy-selector' );
		Array.prototype.forEach.call( copyButtons, function( btn ) {
			btn.addEventListener( 'click', function() {
				var selector = btn.getAttribute( 'data-selector' ) || '';
				copyToClipboard( selector ).then( function() {
					flashCopied( btn );
				}).catch( function() {
					// Fallback: select-and-prompt user to copy manually.
					alert( selector );
				});
			});
		});

		function copyToClipboard( text ) {
			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				return navigator.clipboard.writeText( text );
			}
			// Legacy fallback for older browsers.
			return new Promise( function( resolve, reject ) {
				try {
					var ta = document.createElement( 'textarea' );
					ta.value = text;
					ta.setAttribute( 'readonly', '' );
					ta.style.position = 'absolute';
					ta.style.left = '-9999px';
					document.body.appendChild( ta );
					ta.select();
					document.execCommand( 'copy' );
					document.body.removeChild( ta );
					resolve();
				} catch ( err ) {
					reject( err );
				}
			});
		}

		function flashCopied( btn ) {
			btn.classList.add( 'dfg-copied' );
			var originalLabel = btn.getAttribute( 'aria-label' );
			btn.setAttribute( 'aria-label', '<?php echo esc_js( __( 'Copied!', 'divi5-filterable-gallery' ) ); ?>' );
			setTimeout( function() {
				btn.classList.remove( 'dfg-copied' );
				if ( originalLabel ) {
					btn.setAttribute( 'aria-label', originalLabel );
				}
			}, 1200 );
		}

	})();
	</script>
	<?php
}

/**
 * The selectors documented in the right-hand reference panel.
 *
 * Filterable so site owners and downstream plugins can add their own.
 *
 * @return array<int,array{selector:string,description:string}>
 */
function dfg_class_reference() {
	$reference = array(
		array(
			'selector'    => '.dfg-gallery-filters',
			'description' => __( 'Wrapper around the entire filter UI. Set --dfg-active-bg here, or style margins, padding, and alignment.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters ul',
			'description' => __( 'The filter list. Default is a centered inline-flex with 8px gap. Override flex-wrap, justify-content, or gap here.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-filter',
			'description' => __( 'Each filter list item (the <li>). Use for vertical spacing or row separators.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a',
			'description' => __( 'The clickable button inside each filter. Style typography, padding, background color, border, and radius here.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a:hover',
			'description' => __( 'Hover state for filter buttons. Use for hover background or color shifts.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a:focus-visible',
			'description' => __( 'Keyboard-only focus ring on filter buttons. Default is a 2px outline in --dfg-active-bg.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-gallery-filters a.active',
			'description' => __( 'The active (currently selected) filter button. Default background is --dfg-active-bg with white text.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.dfg-count',
			'description' => __( 'The image-count badge inside each filter button (e.g. "Landscape (12)"). Style font weight, size, or hide it entirely.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '.et_pb_gallery_item.dfg-hidden',
			'description' => __( 'Gallery items currently filtered out. Default fades and collapses; override here to change the filter animation.', 'divi5-filterable-gallery' ),
		),
		array(
			'selector'    => '--dfg-active-bg',
			'description' => __( 'CSS custom property controlling the active button background and focus ring color. Default #2271b1. Set on .dfg-gallery-filters or :root.', 'divi5-filterable-gallery' ),
		),
	);

	return apply_filters( 'dfg_class_reference', $reference );
}

# Chunk 2 Patch — divi5-filterable-gallery.php

Three insertions plus a version bump. Anchors below quote the v1.0.2 file you just shared.

---

## 1. Bump version (header + constant)

**File header — line 6:**

```diff
- * Version:           1.0.2
+ * Version:           1.1.0
```

**Constants block — line 27:**

```diff
- define( 'DFG_VERSION', '1.0.2' );
+ define( 'DFG_VERSION', '1.1.0' );
```

---

## 2. Insert the Admin Settings section

**Where:** Right before the `// Internationalization` section divider — between line 600 (`add_action( 'wp_enqueue_scripts', 'dfg_enqueue_frontend_assets' );`) and line 602 (`// =============================================================================`).

**What to insert:**

```php


// =============================================================================
// Admin Settings (Chunk 2)
// =============================================================================

/**
 * Load the admin settings page module on admin requests only.
 *
 * Settings registration, render callback, and asset enqueue all live
 * in admin/settings-page.php to keep the main plugin file lean.
 */
if ( is_admin() ) {
	require_once DFG_PATH . 'admin/settings-page.php';

	add_action( 'admin_menu',            'dfg_register_settings_page' );
	add_action( 'admin_init',            'dfg_register_settings' );
	add_action( 'admin_enqueue_scripts', 'dfg_enqueue_admin_assets' );
}

/**
 * Print the user's custom CSS in <head> on the front end.
 *
 * Priority 100 ensures this runs AFTER the plugin's default styles
 * (which load via wp_enqueue_style at default priority), so user
 * rules naturally win the cascade without needing !important.
 *
 * @return void
 */
function dfg_output_user_css() {
	$css = get_option( 'dfg_custom_css', '' );

	if ( empty( $css ) || ! is_string( $css ) ) {
		return;
	}

	// esc_html() neutralizes any stray angle brackets that survived
	// sanitization. CSS itself can't execute, so this is sufficient.
	echo "<style id=\"dfg-custom-css\">\n" . esc_html( $css ) . "\n</style>\n";
}
add_action( 'wp_head', 'dfg_output_user_css', 100 );

```

---

## 3. Seed the default CSS option on activation

**Where:** Inside the existing `dfg_activate()` function — line 48–51.

**Replace:**

```php
function dfg_activate() {
	dfg_register_taxonomy();
	flush_rewrite_rules();
}
```

**With:**

```php
function dfg_activate() {
	dfg_register_taxonomy();
	flush_rewrite_rules();

	// Seed the default custom CSS option on first activation only.
	// Uses add_option() rather than update_option() so we don't clobber
	// existing user CSS on plugin reactivation.
	if ( ! file_exists( DFG_PATH . 'admin/settings-page.php' ) ) {
		return;
	}
	require_once DFG_PATH . 'admin/settings-page.php';
	add_option( 'dfg_custom_css', dfg_default_custom_css() );
}
```

The `file_exists()` guard keeps activation safe even if the admin file is missing for some reason (e.g. partial deploy).

---

## File layout after Chunk 2

```
divi5-filterable-gallery/
├── divi5-filterable-gallery.php   (patched per above)
├── uninstall.php                  (unchanged)
├── readme.txt                     (bump version + changelog entry)
├── INSTALL.md                     (unchanged)
├── admin/
│   └── settings-page.php          (NEW)
└── assets/
    ├── filter.css                 (unchanged)
    ├── filter.js                  (unchanged)
    └── admin.css                  (NEW)
```

---

## readme.txt changelog entry

```
= 1.1.0 =
* Add Media → Filterable Gallery settings page with CodeMirror CSS editor.
* Add class reference panel with click-to-copy selectors.
* Default CSS now seeded with theme-bullet fix on fresh installs.
* User CSS prints in <head> at priority 100, after plugin defaults.
```

---

## Smoke-test checklist

After dropping the new files in:

1. Activate the plugin on a fresh test install — confirm `Media → Filterable Gallery` appears in admin sidebar.
2. Open the settings page — confirm the editor loads with the seed CSS already populated.
3. Edit something, try to navigate away — confirm the "unsaved changes" guard fires.
4. Save — confirm "Saved" badge flashes briefly and dirty indicator clears.
5. Click any selector in the right pane — confirm clipboard receives it (and the button flashes green).
6. View page source on a frontend gallery page — confirm `<style id="dfg-custom-css">` appears in `<head>` after `dfg-filter-css`.
7. Disable the rich code editor in your WP user profile — reload settings page — confirm plain textarea fallback works.
